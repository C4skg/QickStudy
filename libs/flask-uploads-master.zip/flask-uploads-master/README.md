# Flask-Uploads

Flask-Uploads provides file uploads for Flask.

## Installation

```sh
pip install flask-uploads
```
